
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'mintae0424',
  applicationName: 'buds-backend',
  appUid: 'FJ1WL8Rb1trY9RN9yW',
  orgUid: '802b239f-c934-428d-adb1-de04c6e6baf3',
  deploymentUid: '5f70ce2f-b58e-4834-8551-31561d8dc738',
  serviceName: 'backend',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '4.5.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'backend-dev-createUser', timeout: 6 };

try {
  const userHandler = require('./routes/users/users.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}